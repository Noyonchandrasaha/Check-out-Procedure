package com.example.noyonfinalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    LinearLayout one,two,three,four;
    ImageView img1,img2,img3,img4,img5,img6,img7,img8,img9,img10,img11,img12;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        one = findViewById(R.id.linerarlayout1);
        two = findViewById(R.id.linerarlayout2);
        three = findViewById(R.id.linerarlayout3);
        four = findViewById(R.id.linerarlayout4);
        img1 = findViewById(R.id.image1);
        img2 = findViewById(R.id.image2);
        img3 = findViewById(R.id.image3);
        img4 = findViewById(R.id.image4);
        img5 = findViewById(R.id.image5);
        img6 = findViewById(R.id.image6);
        img7 = findViewById(R.id.image7);
        img8 = findViewById(R.id.image8);
        img9 = findViewById(R.id.image9);
        img10 = findViewById(R.id.image10);
        img11 = findViewById(R.id.image11);
        img12 = findViewById(R.id.image12);
    }


    public void ProductDetails(View view) {
        String Productname = "Chashi Aromatic Chinigura Rice";
        String ProductWeight = "1 Kg";
        String price = "150";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img1.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails2(View view) {
        String Productname = "Fresh Mosurer Dal";
        String ProductWeight = "1 Kg";
        String price = "140";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img2.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails3(View view) {
        String Productname = "Fresh Salt";
        String ProductWeight = "1 Kg";
        String price = "45";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img3.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails4(View view) {
        String Productname = "Sylon Family Blend Black Tea";
        String ProductWeight = "250 g";
        String price = "250";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img4.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails5(View view) {
        String Productname = "Shaad Brown Flour Lal Atta";
        String ProductWeight = "1 Kg";
        String price = "60";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img5.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails6(View view) {
        String Productname = "Teer Soyabeen Oil";
        String ProductWeight = "1 L";
        String price = "185";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img6.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails7(View view) {
        String Productname = "Teer Sugar";
        String ProductWeight = "1 Kg";
        String price = "130";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img7.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails8(View view) {
        String Productname = "Paragon Brown Egg";
        String ProductWeight = "12 Pcs";
        String price = "160";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img8.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails9(View view) {
        String Productname = "Radhuni Turmeric Holud Powder";
        String ProductWeight = "250 g";
        String price = "125";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img9.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails10(View view) {
        String Productname = "Radhuni Chilli Morich Powder";
        String ProductWeight = "250 g";
        String price = "145";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img10.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails11(View view) {
        String Productname = "Marks Full Cream Milk Powder";
        String ProductWeight = "500 g";
        String price = "510";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img11.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }

    public void ProductDetails12(View view) {
        String Productname = "Pran Premium Ghee";
        String ProductWeight = "200 g";
        String price = "380";
        Fragment frag1 = new ProductOne();
        Bundle bundle = new Bundle();
        bundle.putParcelable("image", ((BitmapDrawable) img12.getDrawable()).getBitmap());
        bundle.putString("Productname",Productname);
        bundle.putString("ProductWeight",ProductWeight);
        bundle.putString("price",price);
        frag1.setArguments(bundle);
        FragmentTransaction fm = getSupportFragmentManager().beginTransaction();
        fm.replace(R.id.mainFrameLayout,frag1).commit();
        one.setVisibility(View.GONE);
        two.setVisibility(View.GONE);
        three.setVisibility(View.GONE);
        four.setVisibility(View.GONE);
    }
}