package com.example.noyonfinalproject;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProductViewHolder extends RecyclerView.ViewHolder{
    TextView nameTextView,priceTextView,WightTextView,QuantityTextview;

    public ProductViewHolder(@NonNull View itemView) {
        super(itemView);
        nameTextView = itemView.findViewById(R.id.productNameTextView);
        priceTextView = itemView.findViewById(R.id.productPriceTextView);
        WightTextView = itemView.findViewById(R.id.productWeightTextView);
        QuantityTextview = itemView.findViewById(R.id.productQuantityTextView);
    }
}
