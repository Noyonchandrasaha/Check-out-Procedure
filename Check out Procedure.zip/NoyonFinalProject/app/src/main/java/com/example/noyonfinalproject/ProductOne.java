package com.example.noyonfinalproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class ProductOne extends Fragment{
    View view;
    TextView name,weight,price,count;
    ImageView img;
    Button btn1,minusbtn,plusbtn,cartbtn;
    ArrayList<Product> cartList = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_product_one, container, false);

        Product listItem = getArguments().getParcelable("listItem");
        name = view.findViewById(R.id.ProductnameId);
        weight = view.findViewById(R.id.ProductWeightId);
        price = view.findViewById(R.id.ProductPriceId);
        img = view.findViewById(R.id.imageview);
        count = view.findViewById(R.id.ItemveiwId);
        btn1 = view.findViewById(R.id.gotoProductId);
        minusbtn = view.findViewById(R.id.ItemMinasId);
        plusbtn = view.findViewById(R.id.ItemPlusId);
        Bundle bundle = this.getArguments();
        Bitmap imgage1 = bundle.getParcelable("image");
        img.setImageBitmap(imgage1);;
        name.setText(bundle.getString("Productname"));
        weight.setText(bundle.getString("ProductWeight"));
        price.setText(bundle.getString("price"));
        float initialprice = Float.parseFloat(price.getText().toString());
        cartbtn = view.findViewById(R.id.GoToCartPageId);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent= new Intent(getContext(),MainActivity2.class);
                startActivity(myIntent);
            }
        });
        minusbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float Count,Price;
                Count = Float.parseFloat(count.getText().toString())-1;
                Price = Float.parseFloat(price.getText().toString())-initialprice;
                count.setText(Count.toString());
                price.setText(Price.toString());

            }
        });
        plusbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Float Count,Price;
                Count = Float.parseFloat(count.getText().toString())+1;
                Price = Float.parseFloat(price.getText().toString())+initialprice;
                count.setText(Count.toString());
                price.setText(Price.toString());
            }
        });
        cartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String Productname = name.getText().toString();
                String ProductWeight = weight.getText().toString();
                String Price = price.getText().toString();
                String quantity = count.getText().toString();
                Product cartItem = new Product(Productname, ProductWeight,Price, quantity);
                cartList.add(cartItem);
                Toast.makeText(getContext(), "Added to cart", Toast.LENGTH_SHORT).show();
                Fragment frag1 = new CartFragment();
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("productList", cartList);
                frag1.setArguments(bundle);
                FragmentTransaction fm = getActivity().getSupportFragmentManager().beginTransaction();
                fm.replace(R.id.mainFrameLayout,frag1).commit();
            }
        });
        return view;
    }
}